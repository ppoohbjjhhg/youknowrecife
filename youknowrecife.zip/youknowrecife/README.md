# YouKnowRecife

> "Entenda seus direitos. Resolva seus problemas."

Desenvolvido por **Pedro Henrique S. Frutuoso** (henriquecomercial1401@gmail.com)

Plataforma de cidadania digital com IA: traduz leis e notícias para linguagem
simples, gera reclamações formais e identifica o órgão público responsável em
Recife.

## O que este projeto é (e o que não é)

Front-end React completo, com 5 ferramentas de IA reais e **login/cadastro
reais via Firebase Authentication**. Ele ainda **não inclui**: painel
administrativo, envio automático de e-mails para órgãos públicos, ou
histórico separado por conta em nuvem (o histórico continua salvo no
navegador — veja "Próximos passos").

## Stack

- React 18 + Vite + Tailwind CSS
- **Firebase Authentication** (e-mail/senha + Google) para login real
- **Firebase Firestore** para guardar o cadastro dos usuários (`users/{uid}`)
- Uma função serverless (`api/claude.js`) que chama a IA (Anthropic ou
  Gemini) sem expor a chave de API no navegador
- Histórico de protocolos salvo em `localStorage` (por navegador/dispositivo)

---

## 1. Editando o projeto no VS Code

1. Instale o [VS Code](https://code.visualstudio.com/) e o
   [Git](https://git-scm.com/), se ainda não tiver
2. Abra o VS Code → menu **Terminal → New Terminal**
3. Clone seu repositório (troque pela sua URL do GitHub):
   ```bash
   git clone https://github.com/SEU-USUARIO/youknowrecife.git
   cd youknowrecife
   code .
   ```
4. Instale as dependências:
   ```bash
   npm install
   ```
5. Rode localmente:
   ```bash
   npm run dev
   ```
   Abre em `http://localhost:5173`

A partir daqui, qualquer alteração some do `localhost` até você mandar pro
GitHub:
```bash
git add .
git commit -m "descrição da mudança"
git push
```
O Vercel redeploya sozinho a cada push na branch `main`.

---

## 2. Configurando o Firebase (login real + cadastro de usuários)

### Criar o projeto

1. Acesse [console.firebase.google.com](https://console.firebase.google.com)
2. Clique em **Adicionar projeto**, dê um nome (ex: `youknowrecife`) e siga o
   assistente (pode desativar o Google Analytics, não é necessário)
3. Dentro do projeto, clique no ícone **`</>`** (Web) para registrar um app
   web. Dê um apelido e clique em **Registrar app**
4. O Firebase mostra um bloco `firebaseConfig` com vários valores
   (`apiKey`, `authDomain`, `projectId`...) — **guarde essa tela aberta**,
   você vai usar esses valores no passo 4 abaixo

### Ativar login por e-mail/senha e Google

1. No menu lateral, vá em **Build → Authentication**
2. Clique em **Get started**
3. Na aba **Sign-in method**, ative:
   - **Email/Password** → clique, ligue o interruptor, salve
   - **Google** → clique, ligue o interruptor, escolha um e-mail de suporte,
     salve

### Ativar o banco de dados (Firestore)

1. No menu lateral, vá em **Build → Firestore Database**
2. Clique em **Create database**
3. Escolha a localização mais próxima (ex: `southamerica-east1`) e modo de
   produção
4. Depois de criado, vá na aba **Rules** e configure para que cada usuário só
   acesse seus próprios dados:
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```
   Clique em **Publish**

### Colocar a configuração no projeto

**Localmente** (arquivo `.env` na raiz do projeto — nunca comite esse
arquivo, ele já está no `.gitignore`):
```bash
cp .env.example .env
```
Edite o `.env` e cole os valores que o Firebase te mostrou:
```
VITE_FIREBASE_API_KEY=AIza...
VITE_FIREBASE_AUTH_DOMAIN=youknowrecife-xxxxx.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=youknowrecife-xxxxx
VITE_FIREBASE_STORAGE_BUCKET=youknowrecife-xxxxx.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef
```

**Na Vercel** (para o site publicado funcionar): vá em **Settings →
Environment Variables** e adicione essas mesmas 6 variáveis (mesmos nomes,
com o prefixo `VITE_`), marcando **Production**. Depois faça um **Redeploy**.

### Autorizar o domínio da Vercel para o login com Google

1. No console do Firebase → **Authentication → Settings → Authorized
   domains**
2. Clique em **Add domain**
3. Adicione o domínio do seu site publicado (ex: `youknowrecife-mu.vercel.app`,
   e depois seu domínio personalizado quando tiver um)

Sem esse passo, o botão "Continuar com Google" funciona no `localhost` mas
falha no site publicado.

---

## 3. Sobre o login

O login agora é real: criar conta gera um usuário no Firebase Authentication
e um documento em `users/{uid}` no Firestore com nome e e-mail. Entrar exige
e-mail e senha corretos (ou conta Google válida) — não é mais possível pular
o login clicando em qualquer botão. A sessão persiste entre recarregamentos
de página até o usuário clicar em sair.

---

## 4. Ativando as ferramentas de IA localmente

`api/claude.js` é uma função no formato Vercel. Duas opções:

**Opção A — Vercel CLI (recomendado)**
```bash
npm install -g vercel
vercel dev
```
Isso serve o front-end e a função `/api/claude` juntos, lendo as variáveis do
seu `.env`.

**Opção B — apenas o front-end**
Rodando só com `npm run dev`, tudo funciona exceto os botões "Gerar com IA"
(não há servidor respondendo em `/api/claude` nesse modo). Isso é esperado.

---

## Deploy (Vercel) — resumo

1. Importe o repositório em [vercel.com/new](https://vercel.com/new)
2. Em **Settings → Environment Variables**, adicione:
   - `ANTHROPIC_API_KEY` **ou** `GEMINI_API_KEY` (dependendo de qual seu
     `api/claude.js` está usando)
   - as 6 variáveis `VITE_FIREBASE_*`
3. Deploy
4. Adicione o domínio da Vercel em **Authorized domains** no Firebase (ver
   seção 2)

## Estrutura

```
├── api/claude.js         # proxy serverless para a IA (Anthropic ou Gemini)
├── src/
│   ├── App.jsx            # toda a aplicação (landing, login, dashboard, ferramentas, histórico, perfil)
│   ├── firebase.js        # inicialização do Firebase (Auth + Firestore)
│   ├── storage.js         # wrapper de histórico sobre localStorage
│   ├── main.jsx
│   └── index.css
├── index.html
└── vite.config.js
```

## Próximos passos para virar produto real

- Painel administrativo (usuários, uso de IA, relatórios)
- Mover o histórico de `localStorage` para o Firestore, namespaced por
  `uid`, para acompanhar o usuário entre dispositivos
- Confirmação humana antes de qualquer envio automático a órgãos públicos —
  os dados de contato gerados pela IA são estimativas e devem ser validados
- Testes automatizados e monitoramento de erros em produção
